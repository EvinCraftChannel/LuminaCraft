#!/bin/bash
curl -fsSL https://github.com/luvit/lit-install/raw/master/install.sh | sh
chmod +x luvit
./luvit main.lua